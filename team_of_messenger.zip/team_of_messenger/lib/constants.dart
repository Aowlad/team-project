import 'package:flutter/material.dart';

class  constants {
  static const regularHeading =
      TextStyle(
          fontSize: 16.0, fontWeight: FontWeight.w600, color: Colors.white
      );
  static const bouldHeading =
      TextStyle(
          fontSize: 20.0, fontWeight: FontWeight.w600, color: Colors.white
      );

}