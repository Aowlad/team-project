package com.example.team_of_messenger

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
